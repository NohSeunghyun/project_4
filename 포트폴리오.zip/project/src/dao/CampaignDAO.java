package dao;

import static db.JdbcUtil.close;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.campaign.CampaignBean;

public class CampaignDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";

	private static CampaignDAO campaignDAO;

	public static CampaignDAO getInstance() {
		if (campaignDAO == null) {
			campaignDAO = new CampaignDAO();
		}
		return campaignDAO;
	}

	public void setConnection(Connection con) {
		this.con = con;
	}

	//모든 캠페인 조회
	public ArrayList<CampaignBean> getCampaign() {
		ArrayList<CampaignBean> campaignList = new ArrayList<CampaignBean>();
		try {
			sql = "select * from campaign_tbl";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			CampaignBean campaign = null;
			
			while (rs.next()) {
				campaign = new CampaignBean();
				
				campaign.setCampaign_no(rs.getInt("campaign_no"));
				campaign.setCampaign_name(rs.getString("campaign_name"));
				campaign.setCampaign_content(rs.getString("campaign_content"));
				campaign.setCampaign_all_fund_raised(rs.getInt("campaign_all_fund_raised"));
				campaign.setCampaign_file(rs.getString("campaign_file"));
				
				campaignList.add(campaign);
			}
		} catch (Exception e) {
			System.out.println("getCampaign 에러 : " + e);
		} finally {
			close(rs);
			close(pstmt);
		}
		return campaignList;
	}
}
