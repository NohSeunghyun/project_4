package vo.campaign;

public class CampaignListBean {
	private int campaign_list_no;
	private String campaign_list_group;
	private String campaign_list_group_intro;
	
	public int getCampaign_list_no() {
		return campaign_list_no;
	}
	public void setCampaign_list_no(int campaign_list_no) {
		this.campaign_list_no = campaign_list_no;
	}
	public String getCampaign_list_group() {
		return campaign_list_group;
	}
	public void setCampaign_list_group(String campaign_list_group) {
		this.campaign_list_group = campaign_list_group;
	}
	public String getCampaign_list_group_intro() {
		return campaign_list_group_intro;
	}
	public void setCampaign_list_group_intro(String campaign_list_group_intro) {
		this.campaign_list_group_intro = campaign_list_group_intro;
	}
	
}