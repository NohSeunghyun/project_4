package svc.campaign;

import static db.JdbcUtil.close;
import static db.JdbcUtil.getConnection;

import java.sql.Connection;
import java.util.ArrayList;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;

public class CampaignListService {

	//모든 캠페인 조회 Service
	public ArrayList<CampaignBean> getCampaign() {
		ArrayList<CampaignBean> campaignList = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignList = campaignDAO.getCampaign();
		} catch (Exception e) {
			System.out.println("getCampaignService에러" + e);
		} finally {
			close(con);
		}
		return campaignList;
	}

}
