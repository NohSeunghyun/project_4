package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;
import vo.login.AdminMemberBean;

public class JoinMemberShip_adminService {

	//관리자 추가 Service
	public boolean joinMemberShip(AdminMemberBean adminMember) {
		boolean isJoinMemberShipSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			int joinMemberShipCount = adminDAO.joinMemberShip_admin(adminMember);
		
			if (joinMemberShipCount > 0) {
				commit(con);
				isJoinMemberShipSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("joinMemberShipAdminService에러" + e);
		} finally {
			close(con);
		}
		return isJoinMemberShipSuccess;
	}

}
