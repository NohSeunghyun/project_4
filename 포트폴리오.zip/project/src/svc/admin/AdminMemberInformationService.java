package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.AdminDAO;
import vo.login.AdminMemberBean;

public class AdminMemberInformationService {

	//관리자모드-관리자 개인정보 조회 Service
	public AdminMemberBean adminMemberInfo(String id) {
		AdminMemberBean adminInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			adminInfo = adminDAO.adminMemberInfo(id);
		} catch (Exception e) {
			System.out.println("adminMemberInfoService에러" + e);
		} finally {
			close(con);
		}
		return adminInfo;
	}

}
