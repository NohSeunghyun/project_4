package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class ChangePwService {

	//일반회원 비밀번호 변경 Service
	public boolean isNormalChangePw(String id, String changePw) {
		boolean isNormalChangePwSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			updateCount = loginDAO.isNormalChangePw(id, changePw);
			
			if (updateCount > 0) {
				commit(con);
				isNormalChangePwSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isNormalChangePwService에러" + e);
		} finally {
			close(con);
		}
		return isNormalChangePwSuccess;
	}

	//기업/단체회원 비밀번호 변경 Service
	public boolean isComgrpChangePw(String id, String changePw) {
		boolean isComgrpChangePwSuccess = false;
		int updateCount = 0;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
		
			updateCount = loginDAO.isComgrpChangePw(id, changePw);
			
			if (updateCount > 0) {
				commit(con);
				isComgrpChangePwSuccess = true;
			} else {
				rollback(con);
			}
		} catch (Exception e) {
			System.out.println("isComgrpChangePwService에러" + e);
		} finally {
			close(con);
		}
		return isComgrpChangePwSuccess;
	}

}
