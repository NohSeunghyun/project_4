package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.login.DeleteMemberService;
import vo.ActionForward;

public class ComgrpMemberDeleteProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String admin_id = request.getParameter("admin_id");
		String id = request.getParameter("delete_id");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			out.println("<script>");
			out.println("alert('삭제할 권한이 없습니다.\\nA등급만 삭제 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			DeleteMemberService deleteMemberService = new DeleteMemberService();
			boolean isComgrpMemberDeleteSuccess = deleteMemberService.isComgrpMemberDelete(id);
			if (!isComgrpMemberDeleteSuccess) {
				out.println("<script>");
				out.println("alert('회원 삭제에 실패하였습니다.');");
				out.println("history.back();");
				out.println("</script>");
			} else {
				forward = new ActionForward("admin_MemberDeleteSuccess.page", false);
			}
		}
		return forward;
	}

}
